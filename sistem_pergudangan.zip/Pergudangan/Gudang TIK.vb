﻿Public Class Gudang_TIK

End Class